// Copyright Epic Games, Inc. All Rights Reserved.

using UnrealBuildTool;

public class ProceduralAnimEditor : ModuleRules
{
	public ProceduralAnimEditor(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(
			new string[]
			{
				"Core",
				"CoreUObject",
				"Engine",
				"AnimGraph",
				"BlueprintGraph",
				"ProceduralAnim"
			}
			);


		PrivateDependencyModuleNames.AddRange(
			new string[]
			{
				"InputCore",
				"SlateCore",
				"UnrealEd",
				"GraphEditor",
				"PropertyEditor",
				"EditorStyle",
				"ContentBrowser",
				"KismetWidgets",
				"ToolMenus",
				"KismetCompiler",
				"Kismet",
				"EditorWidgets"
			}
			);
	}
}
