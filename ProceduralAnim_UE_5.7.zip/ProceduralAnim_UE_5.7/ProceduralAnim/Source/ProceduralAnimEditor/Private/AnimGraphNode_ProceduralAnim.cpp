// Copyright Epic Games, Inc. All Rights Reserved.

#include "AnimGraphNode_ProceduralAnim.h"
#include "UnrealWidget.h"
#include "AnimNodeEditModes.h"
#include "Kismet2/CompilerResultsLog.h"


#define LOCTEXT_NAMESPACE "ProceduralAnim"

FLinearColor UAnimGraphNode_ProceduralAnim::GetNodeTitleColor() const
{
	return FLinearColor::Yellow;
}

FText UAnimGraphNode_ProceduralAnim::GetControllerDescription() const
{
	return LOCTEXT("ProceduralAnim", "Procedural Anim");
}

void UAnimGraphNode_ProceduralAnim::ValidateAnimNodeDuringCompilation(USkeleton* ForSkeleton, FCompilerResultsLog& MessageLog)
{

}


void UAnimGraphNode_ProceduralAnim::CopyPinDefaultsToNodeData(UEdGraphPin* InPin)
{
	return;
}

FText UAnimGraphNode_ProceduralAnim::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	if ((TitleType == ENodeTitleType::ListView || TitleType == ENodeTitleType::MenuTitle) && (Node.FirstBone.BoneName == NAME_None))
	{
		return GetControllerDescription();
	}
	else
	{

		FFormatNamedArguments Args;
		Args.Add(TEXT("ControllerDescription"), GetControllerDescription());
		Args.Add(TEXT("BoneName"), FText::FromName(Node.FirstBone.BoneName));


		if (TitleType == ENodeTitleType::ListView || TitleType == ENodeTitleType::MenuTitle)
		{
			CachedNodeTitles.SetCachedTitle(TitleType, FText::Format(LOCTEXT("AnimGraphNode_ProceduralAnim_ListTitle", "{ControllerDescription} - Bone: {BoneName}"), Args), this);
		}
		else
		{
			CachedNodeTitles.SetCachedTitle(TitleType, FText::Format(LOCTEXT("AnimGraphNode_ProceduralAnim_Title", "{ControllerDescription}\nBone: {BoneName}"), Args), this);
		}
	}
	return CachedNodeTitles[TitleType];
}

FText UAnimGraphNode_ProceduralAnim::GetTooltipText() const
{
	return LOCTEXT("ProceduralAnimTooltip", "Applies a procedural sine-wave rotation across a bone chain (e.g. spine, tail).");
}


#undef LOCTEXT_NAMESPACE
