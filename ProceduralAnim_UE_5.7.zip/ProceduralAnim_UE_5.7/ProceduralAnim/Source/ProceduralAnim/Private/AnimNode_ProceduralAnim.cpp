// Copyright Epic Games, Inc. All Rights Reserved.

#include "AnimNode_ProceduralAnim.h"
#include "AnimationRuntime.h"
#include "Animation/AnimInstanceProxy.h"
#include "Animation/AnimTrace.h"


FAnimNode_ProceduralAnim::FAnimNode_ProceduralAnim()
	:RotationX(true)
	, RotationY(true)
	, RotationZ(true)
	, XSpeed(float(1.0f))
	, YSpeed(float(1.0f))
	, ZSpeed(float(1.0f))
	, MyIntervalX(float(0.0f))
	, MyIntervalY(float(0.0f))
	, MyIntervalZ(float(0.0f))
	, Frequency(float(0.06f))
	, BoneLength(0)
	, XTime(float(0.0f))
	, YTime(float(0.0f))
	, ZTime(float(0.0f))




{}

void FAnimNode_ProceduralAnim::GatherDebugData(FNodeDebugData& DebugData)
{
	FString DebugLine = DebugData.GetNodeName(this);

}


void FAnimNode_ProceduralAnim::UpdateInternal(const FAnimationUpdateContext& Context)
{
    Super::UpdateInternal(Context);
	CachedDeltaTime = Context.GetDeltaTime();
}


void FAnimNode_ProceduralAnim::EvaluateSkeletalControl_AnyThread(FComponentSpacePoseContext& Output, TArray<FBoneTransform>& OutBoneTransforms)
{
	DECLARE_SCOPE_HIERARCHICAL_COUNTER_ANIMNODE(EvaluateSkeletalControl_AnyThread)
	check(OutBoneTransforms.Num() == 0);
	// const FBoneContainer& BoneContainer = Output.Pose.GetPose().GetBoneContainer();
	// FTransform ComponentTransform = Output.AnimInstanceProxy->GetComponentTransform();


	int32 k = FirstBone.BoneIndex;
	int32 LastIndexNum = k + BoneLength;

	float j = 0.f;
	float intervalX = MyIntervalX / (BoneLength);
	float intervalY = MyIntervalY / (BoneLength);
	float intervalZ = MyIntervalZ / (BoneLength);

	float intervalXX = 0;
	float intervalYY = 0;
	float intervalZZ = 0;

	FTransform ParentOriginalTM;
	FTransform ParentNewTM;

	for (int32 i = k; i <= LastIndexNum; i++)
	{
		if (MyAngleX != 0)
		{

			intervalXX = intervalXX + intervalX;
		}
		else
		{
			intervalXX = 0;
		}
		if (MyAngleY != 0)
		{

			intervalYY = intervalYY + intervalY;
		}
		else
		{
			intervalYY = 0;
		}
		if (MyAngleZ != 0)
		{

			intervalZZ = intervalZZ + intervalZ;
		}
		else
		{
			intervalZZ = 0;
		}

		XTime += CachedDeltaTime * 0.1;
		YTime += CachedDeltaTime * 0.1;
		ZTime += CachedDeltaTime * 0.1;

		float MySinTranX = FMath::InterpSinInOut((MyAngleX + intervalXX) * 0.5, ((MyAngleX + intervalXX) * -0.5), XTime * XSpeed - j);
		float MySinTranY = FMath::InterpSinInOut((MyAngleY + intervalYY) * 0.5, ((MyAngleY + intervalYY) * -0.5), YTime * YSpeed - j);
		float MySinTranZ = FMath::InterpSinInOut((MyAngleZ + intervalZZ) * 0.5, ((MyAngleZ + intervalZZ) * -0.5), ZTime * ZSpeed - j);



		FRotator FinalTran(RotationY * MySinTranY, RotationZ * MySinTranZ, RotationX * MySinTranX);


		const FQuat BoneQuatTran(FinalTran);
		FCompactPoseBoneIndex CurrentIndex = FCompactPoseBoneIndex(i);

		FTransform TransBoneTM = Output.Pose.GetComponentSpaceTransform(CurrentIndex);
		FTransform CurrentOriginalTM = TransBoneTM;

		TransBoneTM.SetRotation(BoneQuatTran * TransBoneTM.GetRotation());

		if (i != k)
		{
			FVector RelativeOffset = CurrentOriginalTM.GetLocation() - ParentOriginalTM.GetLocation();
			RelativeOffset = BoneQuatTran.RotateVector(RelativeOffset);
			TransBoneTM.SetLocation(ParentNewTM.GetLocation() + RelativeOffset);

		}

		OutBoneTransforms.Add(FBoneTransform(CurrentIndex, TransBoneTM));

		ParentOriginalTM = CurrentOriginalTM;
		ParentNewTM = TransBoneTM;

		j += Frequency;

	}
}

bool FAnimNode_ProceduralAnim::IsValidToEvaluate(const USkeleton* Skeleton, const FBoneContainer& RequiredBones)
{
	return (FirstBone.IsValidToEvaluate(RequiredBones)) && (EndBone.IsValidToEvaluate(RequiredBones));
}



void FAnimNode_ProceduralAnim::InitializeBoneReferences(const FBoneContainer& RequiredBones)
{
	FirstBone.Initialize(RequiredBones);
	EndBone.Initialize(RequiredBones);

	BoneLength = RequiredBones.GetDepthBetweenBones(EndBone.BoneIndex, FirstBone.BoneIndex);
}

